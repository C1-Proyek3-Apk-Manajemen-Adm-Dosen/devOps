<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CheckRole
{
    /**
     * Handle an incoming request.
     */
    public function handle(Request $request, Closure $next, ...$roles)
    {
        // Cek apakah user sudah login
        if (!Auth::check()) {
            return redirect()->route('login');
        }

        $user = Auth::user();

        // Cek apakah role user termasuk dalam role yang diizinkan
        if (!in_array($user->role, $roles)) {
            // Kalau tidak punya izin → redirect ke dashboard sesuai role-nya
            switch ($user->role) {
                case 'tu':
                    return redirect()->route('tu.dashboard');
                case 'dosen':
                    return redirect()->route('dosen.dashboard');
                case 'koordinator':
                    return redirect()->route('kaprodi.dashboard');
                default:
                    return redirect()->route('login')->withErrors('Akses ditolak!');
            }
        }

        // Kalau role sesuai, lanjut ke halaman yang diminta
        return $next($request);
    }
}
