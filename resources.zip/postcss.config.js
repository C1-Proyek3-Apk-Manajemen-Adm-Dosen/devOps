export default {
  plugins: {
    '@tailwindcss/postcss': {},  // pakai plugin baru
    autoprefixer: {},
  },
}
