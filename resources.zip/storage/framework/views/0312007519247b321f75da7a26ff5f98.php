

<?php $__env->startSection('title', 'Dashboard Kaprodi'); ?>

<?php $__env->startSection('content'); ?>
    <div class="flex justify-center items-center h-full">
        <p class="text-gray-600 text-center">Ini halaman dashboard Kaprodi.</p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Proyek 3\Sidora\devOps\resources\views/kaprodi/dashboard.blade.php ENDPATH**/ ?>