

<?php $__env->startSection('title', 'Upload Dokumen - SiDoRa'); ?>

<?php $__env->startSection('content'); ?>
    <div class="flex justify-center items-center h-full">
        <h1 class="text-gray-700 text-lg font-semibold">Ini halaman Portofolio Dosen</h1>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Proyek 3\Sidora\devOps\resources\views/dosen/portofolio.blade.php ENDPATH**/ ?>