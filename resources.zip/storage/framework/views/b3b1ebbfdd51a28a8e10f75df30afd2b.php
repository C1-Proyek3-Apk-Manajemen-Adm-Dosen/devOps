

<?php $__env->startSection('title', 'Dashboard Dosen'); ?>

<?php $__env->startSection('content'); ?>
    <div class="flex justify-center items-center h-full">
        <p class="text-gray-600 text-center">Ini halaman dashboard Dosen.</p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Proyek 3\Proyek3_SiDoRa\resources\views/dosen/dashboard.blade.php ENDPATH**/ ?>