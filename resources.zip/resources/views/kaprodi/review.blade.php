@extends('layouts.app')

@section('title', 'Upload Dokumen - SiDoRa')

@section('content')
    <div class="flex justify-center items-center h-full">
        <h1 class="text-gray-700 text-lg font-semibold">Ini halaman Review Dokumen Kaprodi</h1>
    </div>
@endsection
