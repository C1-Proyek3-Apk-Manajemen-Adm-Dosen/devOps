@extends('layouts.app')

@section('title', 'Dashboard Kaprodi')

@section('content')
    <div class="flex justify-center items-center h-full">
        <p class="text-gray-600 text-center">Ini halaman dashboard Kaprodi.</p>
    </div>
@endsection
