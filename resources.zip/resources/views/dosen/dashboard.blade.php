@extends('layouts.app')

@section('title', 'Dashboard Dosen')

@section('content')
    <div class="flex justify-center items-center h-full">
        <p class="text-gray-600 text-center">Ini halaman dashboard Dosen.</p>
    </div>
@endsection
